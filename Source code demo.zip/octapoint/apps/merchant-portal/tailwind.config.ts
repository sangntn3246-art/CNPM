import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0F1B2B",       // deep navy — primary text / surfaces
        parchment: "#F6F3EC", // warm off-white background
        signal: "#1F6F5C",    // muted teal-green — the one accent (loyalty/growth)
        brass: "#B98B3E",     // warm brass — secondary accent for currency/points
        line: "#DAD3C2",      // hairline border color
      },
      fontFamily: {
        display: ["'Fraunces'", "serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
export default config;
