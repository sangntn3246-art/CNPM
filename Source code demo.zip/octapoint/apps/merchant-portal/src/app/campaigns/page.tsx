"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";

interface Campaign {
  id: string;
  name: string;
  multiplierBps: number;
  startsAt: string;
  endsAt: string;
  isActive: boolean;
}

export default function CampaignsPage() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [form, setForm] = useState({ name: "", multiplier: "2.0", startsAt: "", endsAt: "" });

  const refresh = () => api.campaigns().then((r) => setCampaigns(r.campaigns));
  useEffect(() => { refresh(); }, []);

  async function handleCreate() {
    await api.createCampaign({
      name: form.name,
      multiplierBps: Math.round(parseFloat(form.multiplier || "1") * 10000),
      startsAt: new Date(form.startsAt).toISOString(),
      endsAt: new Date(form.endsAt).toISOString(),
    });
    setForm({ name: "", multiplier: "2.0", startsAt: "", endsAt: "" });
    refresh();
  }

  return (
    <div>
      <header className="mb-8">
        <h1 className="font-display text-4xl">Campaigns</h1>
        <p className="text-ink/60 mt-1">Multiplier promotions your AI agent or ops team can launch on demand.</p>
      </header>

      <div className="hairline bg-white rounded-sm p-5 mb-8 grid grid-cols-4 gap-3 items-end">
        <Field label="Name">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="hairline rounded-sm px-3 py-2 text-sm w-full" placeholder="Weekend 2x" />
        </Field>
        <Field label="Multiplier">
          <input value={form.multiplier} onChange={(e) => setForm({ ...form, multiplier: e.target.value })}
            className="hairline rounded-sm px-3 py-2 text-sm w-full" placeholder="2.0" />
        </Field>
        <Field label="Starts">
          <input type="datetime-local" value={form.startsAt} onChange={(e) => setForm({ ...form, startsAt: e.target.value })}
            className="hairline rounded-sm px-3 py-2 text-sm w-full" />
        </Field>
        <Field label="Ends">
          <input type="datetime-local" value={form.endsAt} onChange={(e) => setForm({ ...form, endsAt: e.target.value })}
            className="hairline rounded-sm px-3 py-2 text-sm w-full" />
        </Field>
        <button onClick={handleCreate} className="col-span-4 bg-signal text-white text-sm px-4 py-2 rounded-sm hover:bg-signal/90 mt-1">
          Launch campaign
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {campaigns.map((c) => (
          <div key={c.id} className="hairline bg-white rounded-sm px-5 py-4">
            <div className="flex justify-between items-baseline">
              <span className="font-display text-lg">{c.name}</span>
              <span className="text-brass font-mono">{(c.multiplierBps / 10000).toFixed(1)}x</span>
            </div>
            <div className="text-xs text-ink/50 mt-1">
              {new Date(c.startsAt).toLocaleDateString()} – {new Date(c.endsAt).toLocaleDateString()}
              {" · "}{c.isActive ? "active" : "inactive"}
            </div>
          </div>
        ))}
        {campaigns.length === 0 && <div className="text-ink/40 text-sm">No campaigns yet.</div>}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs text-ink/50 mb-1">{label}</div>
      {children}
    </div>
  );
}
