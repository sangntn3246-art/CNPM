"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";

interface Analytics {
  accountCount: number;
  transactionsByType: { type: string; count: number; totalAmount: string }[];
  recentTransactions: { id: string; type: string; amount: string; createdAt: string }[];
}

export default function OverviewPage() {
  const [data, setData] = useState<Analytics | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.analytics().then(setData).catch((e) => setError(String(e.message ?? e)));
  }, []);

  const issued = data?.transactionsByType.find((t) => t.type === "ISSUE")?.totalAmount ?? "0";
  const redeemed = data?.transactionsByType.find((t) => t.type === "REDEEM")?.totalAmount ?? "0";

  return (
    <div>
      <header className="mb-10">
        <h1 className="font-display text-4xl">Overview</h1>
        <p className="text-ink/60 mt-1">Your loyalty program, at a glance.</p>
      </header>

      {error && (
        <div className="hairline bg-white px-4 py-3 text-sm text-ink/70 mb-6">
          Couldn't reach the gateway ({error}). Is the API running at{" "}
          <code className="font-mono text-xs">NEXT_PUBLIC_GATEWAY_URL</code>?
        </div>
      )}

      <div className="grid grid-cols-3 gap-4 mb-10">
        <Stat label="Enrolled members" value={data?.accountCount ?? "—"} />
        <Stat label="Credits issued" value={issued} accent="brass" />
        <Stat label="Credits redeemed" value={redeemed} accent="signal" />
      </div>

      <section>
        <h2 className="font-display text-xl mb-3">Recent activity</h2>
        <div className="hairline bg-white rounded-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-ink/50 border-b border-line">
                <th className="px-4 py-3 font-normal">Type</th>
                <th className="px-4 py-3 font-normal">Amount</th>
                <th className="px-4 py-3 font-normal">When</th>
              </tr>
            </thead>
            <tbody>
              {data?.recentTransactions.length ? (
                data.recentTransactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-line last:border-0">
                    <td className="px-4 py-3">{tx.type}</td>
                    <td className="px-4 py-3 tabular font-mono">{tx.amount}</td>
                    <td className="px-4 py-3 text-ink/60">{new Date(tx.createdAt).toLocaleString()}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="px-4 py-6 text-ink/40" colSpan={3}>
                    No transactions yet. Issue a credit via the SDK, MCP tool, or seed script to see it here.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string | number; accent?: "brass" | "signal" }) {
  const color = accent === "brass" ? "text-brass" : accent === "signal" ? "text-signal" : "text-ink";
  return (
    <div className="hairline bg-white rounded-sm px-5 py-4">
      <div className="text-xs text-ink/40 mb-2">{label}</div>
      <div className={`font-display text-3xl tabular ${color}`}>{value}</div>
    </div>
  );
}
