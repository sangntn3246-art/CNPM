"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";

interface Tx {
  id: string;
  externalUserId: string;
  type: string;
  amount: string;
  balanceAfter: string;
  reason: string | null;
  createdAt: string;
}

export default function HistoryPage() {
  const [txs, setTxs] = useState<Tx[]>([]);
  const [filter, setFilter] = useState("");

  const refresh = (userId?: string) => api.transactions(userId).then((r) => setTxs(r.transactions));
  useEffect(() => { refresh(); }, []);

  return (
    <div>
      <header className="mb-8">
        <h1 className="font-display text-4xl">Transactions</h1>
        <p className="text-ink/60 mt-1">Immutable, object-backed audit trail for every issue and redeem.</p>
      </header>

      <div className="flex gap-2 mb-6">
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && refresh(filter || undefined)}
          placeholder="Filter by user id"
          className="hairline bg-white rounded-sm px-3 py-2 text-sm w-64 outline-none focus:ring-1 focus:ring-signal"
        />
        <button onClick={() => refresh(filter || undefined)} className="text-sm px-4 py-2 hairline rounded-sm bg-white hover:bg-ink/5">
          Search
        </button>
      </div>

      <div className="hairline bg-white rounded-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-ink/50 border-b border-line">
              <th className="px-4 py-3 font-normal">User</th>
              <th className="px-4 py-3 font-normal">Type</th>
              <th className="px-4 py-3 font-normal">Amount</th>
              <th className="px-4 py-3 font-normal">Balance after</th>
              <th className="px-4 py-3 font-normal">Reason</th>
              <th className="px-4 py-3 font-normal">When</th>
            </tr>
          </thead>
          <tbody>
            {txs.map((tx) => (
              <tr key={tx.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3 font-mono text-xs">{tx.externalUserId}</td>
                <td className="px-4 py-3">{tx.type}</td>
                <td className="px-4 py-3 tabular font-mono">{tx.amount}</td>
                <td className="px-4 py-3 tabular font-mono text-ink/60">{tx.balanceAfter}</td>
                <td className="px-4 py-3 text-ink/60">{tx.reason ?? "—"}</td>
                <td className="px-4 py-3 text-ink/60">{new Date(tx.createdAt).toLocaleString()}</td>
              </tr>
            ))}
            {txs.length === 0 && (
              <tr><td className="px-4 py-6 text-ink/40" colSpan={6}>No transactions found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
