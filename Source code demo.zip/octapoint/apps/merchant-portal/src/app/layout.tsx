import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "OctaPoint — Merchant Console",
  description: "Manage your credit & loyalty program",
};

const nav = [
  { href: "/", label: "Overview" },
  { href: "/campaigns", label: "Campaigns" },
  { href: "/api-keys", label: "API Keys" },
  { href: "/history", label: "Transactions" },
];

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-body">
        <div className="min-h-screen flex">
          <aside className="w-60 shrink-0 border-r border-line px-6 py-8 flex flex-col gap-10">
            <div>
              <div className="font-display text-2xl tracking-tight">OctaPoint</div>
              <div className="text-xs text-ink/50 mt-0.5">Merchant Console</div>
            </div>
            <nav className="flex flex-col gap-1">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-sm px-3 py-2 rounded-sm hover:bg-ink/5 text-ink/80 hover:text-ink transition-colors"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto text-xs text-ink/40 leading-relaxed">
              Sui Testnet · off-chain fast path active
            </div>
          </aside>
          <main className="flex-1 px-10 py-8 max-w-5xl">{children}</main>
        </div>
      </body>
    </html>
  );
}
