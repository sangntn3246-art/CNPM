"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";

interface ApiKey {
  id: string;
  keyId: string;
  label: string;
  isActive: boolean;
  createdAt: string;
  lastUsedAt: string | null;
}

export default function ApiKeysPage() {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [label, setLabel] = useState("");
  const [justCreated, setJustCreated] = useState<{ keyId: string; secret: string } | null>(null);

  const refresh = () => api.apiKeys().then((r) => setKeys(r.apiKeys));
  useEffect(() => { refresh(); }, []);

  async function handleCreate() {
    const created = await api.createApiKey(label || "unnamed key");
    setJustCreated(created);
    setLabel("");
    refresh();
  }

  async function handleRevoke(keyId: string) {
    await api.revokeApiKey(keyId);
    refresh();
  }

  return (
    <div>
      <header className="mb-8">
        <h1 className="font-display text-4xl">API keys</h1>
        <p className="text-ink/60 mt-1">
          Used by the SDK and MCP Server to sign every request with HMAC-SHA256.
        </p>
      </header>

      {justCreated && (
        <div className="hairline bg-white rounded-sm px-5 py-4 mb-6">
          <div className="text-sm text-signal mb-2">Save this secret now — it won't be shown again.</div>
          <div className="font-mono text-xs space-y-1">
            <div>key id: {justCreated.keyId}</div>
            <div>secret: {justCreated.secret}</div>
          </div>
        </div>
      )}

      <div className="flex gap-2 mb-8">
        <input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="Label, e.g. \"POS terminal\""
          className="hairline bg-white rounded-sm px-3 py-2 text-sm flex-1 outline-none focus:ring-1 focus:ring-signal"
        />
        <button
          onClick={handleCreate}
          className="bg-ink text-parchment text-sm px-4 py-2 rounded-sm hover:bg-ink/90"
        >
          Generate key
        </button>
      </div>

      <div className="hairline bg-white rounded-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-ink/50 border-b border-line">
              <th className="px-4 py-3 font-normal">Label</th>
              <th className="px-4 py-3 font-normal">Key id</th>
              <th className="px-4 py-3 font-normal">Status</th>
              <th className="px-4 py-3 font-normal">Last used</th>
              <th className="px-4 py-3 font-normal"></th>
            </tr>
          </thead>
          <tbody>
            {keys.map((k) => (
              <tr key={k.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3">{k.label}</td>
                <td className="px-4 py-3 font-mono text-xs">{k.keyId}</td>
                <td className="px-4 py-3">{k.isActive ? "Active" : "Revoked"}</td>
                <td className="px-4 py-3 text-ink/60">
                  {k.lastUsedAt ? new Date(k.lastUsedAt).toLocaleString() : "Never"}
                </td>
                <td className="px-4 py-3 text-right">
                  {k.isActive && (
                    <button onClick={() => handleRevoke(k.keyId)} className="text-xs text-ink/50 hover:text-ink">
                      Revoke
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
