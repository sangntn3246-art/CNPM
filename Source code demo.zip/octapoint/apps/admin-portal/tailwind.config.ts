import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        void: "#0B0E14",     // near-black operator console background
        steel: "#141924",    // panel surface
        wire: "#262E3D",     // hairline borders on dark
        mist: "#AEB8C9",     // secondary text on dark
        alert: "#D9714E",    // warm amber-red — status/alerts only
        ok: "#4F9C82",       // muted green — healthy status
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
export default config;
