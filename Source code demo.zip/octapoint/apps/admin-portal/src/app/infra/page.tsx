"use client";

import { useEffect, useState } from "react";
import { adminApi } from "@/lib/api";

interface InfraStatus {
  gatewayUptime: number;
  approxRequestsLast5s: number;
  chainMode: string;
  gasTreasury: { note: string; network: string };
}

export default function InfraPage() {
  const [status, setStatus] = useState<InfraStatus | null>(null);

  useEffect(() => {
    const load = () => adminApi.infraStatus().then(setStatus).catch(() => {});
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <div>
      <header className="mb-10">
        <h1 className="font-display text-4xl text-white">Infrastructure</h1>
        <p className="text-mist mt-1">API Gateway, chain settlement mode, and gas sponsorship treasury.</p>
      </header>

      <div className="grid grid-cols-2 gap-4">
        <Panel title="Gateway">
          <Row label="Uptime" value={status ? `${Math.floor(status.gatewayUptime)}s` : "—"} />
          <Row label="Requests (last ~5s, sampled)" value={status?.approxRequestsLast5s ?? "—"} />
        </Panel>

        <Panel title="Blockchain settlement">
          <Row label="Mode" value={status?.chainMode ?? "—"} accent={status?.chainMode === "onchain" ? "ok" : undefined} />
          <Row label="Network" value={status?.gasTreasury.network ?? "—"} />
        </Panel>

        <Panel title="Enoki gas sponsorship" span>
          <p className="text-sm text-mist leading-relaxed">
            {status?.gasTreasury.note ?? "Loading…"}
          </p>
        </Panel>
      </div>
    </div>
  );
}

function Panel({ title, children, span }: { title: string; children: React.ReactNode; span?: boolean }) {
  return (
    <div className={`hairline-dark bg-steel rounded-sm px-5 py-4 ${span ? "col-span-2" : ""}`}>
      <div className="font-display text-white mb-3">{title}</div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Row({ label, value, accent }: { label: string; value: string | number; accent?: "ok" }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-mist">{label}</span>
      <span className={`font-mono tabular ${accent === "ok" ? "text-ok" : "text-white"}`}>{value}</span>
    </div>
  );
}
