"use client";

import { useEffect, useState } from "react";
import { adminApi } from "@/lib/api";

interface Merchant {
  id: string;
  name: string;
  slug: string;
  status: "PENDING" | "ACTIVE" | "SUSPENDED";
  earnRateBps: number;
  redeemRateBps: number;
  createdAt: string;
  _count: { accounts: number; apiKeys: number };
}

interface Overview {
  merchantCount: number;
  activeMerchants: number;
  accountCount: number;
  transactionsByType: { type: string; count: number; totalAmount: string }[];
}

export default function TenantsPage() {
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refresh = () => {
    adminApi.tenants().then((r) => setMerchants(r.merchants)).catch((e) => setError(String(e.message ?? e)));
    adminApi.analyticsOverview().then(setOverview).catch(() => {});
  };
  useEffect(() => { refresh(); }, []);

  async function setStatus(id: string, status: Merchant["status"]) {
    await adminApi.setStatus(id, status);
    refresh();
  }

  return (
    <div>
      <header className="mb-10">
        <h1 className="font-display text-4xl text-white">Tenants</h1>
        <p className="text-mist mt-1">Every merchant onboarded onto OctaPoint.</p>
      </header>

      {error && (
        <div className="hairline-dark bg-steel px-4 py-3 text-sm text-alert mb-6 rounded-sm">
          {error.includes("401") ? "Unauthorized — check NEXT_PUBLIC_ADMIN_TOKEN matches the gateway's ADMIN_TOKEN." : error}
        </div>
      )}

      <div className="grid grid-cols-3 gap-4 mb-10">
        <Stat label="Total merchants" value={overview?.merchantCount ?? "—"} />
        <Stat label="Active merchants" value={overview?.activeMerchants ?? "—"} accent="ok" />
        <Stat label="Loyalty accounts" value={overview?.accountCount ?? "—"} />
      </div>

      <div className="hairline-dark bg-steel rounded-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-mist border-b border-wire">
              <th className="px-4 py-3 font-normal">Merchant</th>
              <th className="px-4 py-3 font-normal">Status</th>
              <th className="px-4 py-3 font-normal">Accounts</th>
              <th className="px-4 py-3 font-normal">API keys</th>
              <th className="px-4 py-3 font-normal">Earn / Redeem bps</th>
              <th className="px-4 py-3 font-normal"></th>
            </tr>
          </thead>
          <tbody>
            {merchants.map((m) => (
              <tr key={m.id} className="border-b border-wire last:border-0">
                <td className="px-4 py-3">
                  <div className="text-white">{m.name}</div>
                  <div className="text-xs text-mist">{m.slug}</div>
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={m.status} />
                </td>
                <td className="px-4 py-3 tabular font-mono">{m._count.accounts}</td>
                <td className="px-4 py-3 tabular font-mono">{m._count.apiKeys}</td>
                <td className="px-4 py-3 tabular font-mono text-mist">{m.earnRateBps} / {m.redeemRateBps}</td>
                <td className="px-4 py-3 text-right space-x-2">
                  {m.status !== "ACTIVE" && (
                    <button onClick={() => setStatus(m.id, "ACTIVE")} className="text-xs text-ok hover:underline">Activate</button>
                  )}
                  {m.status !== "SUSPENDED" && (
                    <button onClick={() => setStatus(m.id, "SUSPENDED")} className="text-xs text-alert hover:underline">Suspend</button>
                  )}
                </td>
              </tr>
            ))}
            {merchants.length === 0 && !error && (
              <tr><td className="px-4 py-6 text-mist" colSpan={6}>No merchants onboarded yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Merchant["status"] }) {
  const color = status === "ACTIVE" ? "text-ok" : status === "SUSPENDED" ? "text-alert" : "text-mist";
  return <span className={`text-xs ${color}`}>{status.toLowerCase()}</span>;
}

function Stat({ label, value, accent }: { label: string; value: string | number; accent?: "ok" }) {
  return (
    <div className="hairline-dark bg-steel rounded-sm px-5 py-4">
      <div className="text-xs text-mist mb-2">{label}</div>
      <div className={`font-display text-3xl tabular ${accent === "ok" ? "text-ok" : "text-white"}`}>{value}</div>
    </div>
  );
}
