import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "OctaPoint — Operator Console",
  description: "Platform-wide tenant and infrastructure control",
};

const nav = [
  { href: "/", label: "Tenants" },
  { href: "/infra", label: "Infrastructure" },
];

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-body">
        <div className="min-h-screen flex">
          <aside className="w-60 shrink-0 border-r border-wire px-6 py-8 flex flex-col gap-10">
            <div>
              <div className="font-display text-2xl tracking-tight text-white">OctaPoint</div>
              <div className="text-xs text-mist mt-0.5">Operator Console</div>
            </div>
            <nav className="flex flex-col gap-1">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-sm px-3 py-2 rounded-sm hover:bg-white/5 text-mist hover:text-white transition-colors"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto text-xs text-mist/60 leading-relaxed">
              Platform admin surface · bearer-token gated
            </div>
          </aside>
          <main className="flex-1 px-10 py-8 max-w-5xl">{children}</main>
        </div>
      </body>
    </html>
  );
}
