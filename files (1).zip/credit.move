/// Module: octapoint::credit
/// Lõi nghiệp vụ của OctaPoint: TreasuryCap kiểm soát hạn mức mint theo
/// epoch, CreditObject đại diện số dư điểm của người dùng. Phụ thuộc vào
/// `merchant` (kiểm tra quyền) và `policy` (đọc công thức earn/redeem).
module octapoint::credit {
    use sui::object::{Self, UID, ID};
    use sui::tx_context::{Self, TxContext};
    use sui::transfer;
    use sui::event;
    use std::option::{Self, Option};

    use octapoint::merchant::{Self, MerchantCap};
    use octapoint::policy::{Self, DynamicPolicyRule};

    // ------------------------------------------------------------------
    // Error codes
    // ------------------------------------------------------------------
    const E_MERCHANT_SUSPENDED: u64 = 0;
    const E_MERCHANT_MISMATCH: u64 = 1;
    const E_EPOCH_CAP_EXCEEDED: u64 = 2;
    const E_INSUFFICIENT_BALANCE: u64 = 3;
    const E_OBJECT_LOCKED: u64 = 4;
    const E_OBJECT_NOT_LOCKED: u64 = 5;
    const E_REDEEM_REJECTED_BY_POLICY: u64 = 6;
    const E_CREDIT_MERCHANT_MISMATCH: u64 = 7;

    // ------------------------------------------------------------------
    // Hạng thành viên
    // ------------------------------------------------------------------
    const TIER_BRONZE: u8 = 0;
    const TIER_SILVER: u8 = 1;
    const TIER_GOLD: u8 = 2;
    const TIER_PLATINUM: u8 = 3;

    // ------------------------------------------------------------------
    // Object Schema
    // ------------------------------------------------------------------

    /// Kiểm soát toàn bộ hoạt động mint/burn điểm thưởng của một merchant.
    /// Là shared object vì nhiều giao dịch mint/redeem có thể cần truy cập
    /// đồng thời (Sui xử lý tuần tự hoá qua consensus cho shared object).
    public struct TreasuryCap has key, store {
        id: UID,
        merchant_id: ID,
        total_minted: u64,
        total_burned: u64,
        mint_cap_per_epoch: u64,
        current_epoch_minted: u64,
        current_epoch: u64,
    }

    /// Đại diện số dư điểm thưởng của một người dùng tại một merchant cụ
    /// thể. Một user có thể sở hữu nhiều CreditObject nếu tích điểm ở nhiều
    /// merchant khác nhau (owned object, lưu trong ví user).
    public struct CreditObject has key, store {
        id: UID,
        owner: address,
        merchant_id: ID,
        balance: u64,
        tier: u8,
        expiry_ms: Option<u64>,
        last_updated_ms: u64,
        locked: bool,
    }

    // ------------------------------------------------------------------
    // Events — Backend lắng nghe để đồng bộ cache Redis/Postgres
    // ------------------------------------------------------------------
    public struct MintEvent has copy, drop {
        merchant_id: ID,
        user_addr: address,
        points: u64,
        new_balance: u64,
    }

    public struct RedeemEvent has copy, drop {
        merchant_id: ID,
        user_addr: address,
        amount: u64,
    }

    public struct BurnEvent has copy, drop {
        merchant_id: ID,
        user_addr: address,
        amount: u64,
        total_burned: u64,
    }

    // ------------------------------------------------------------------
    // MerchantCap.request_treasury_mint_quota()
    // Merchant khởi tạo TreasuryCap của riêng mình (chỉ một lần / merchant).
    // ------------------------------------------------------------------
    public entry fun request_treasury_mint_quota(
        merchant_cap: &MerchantCap,
        mint_cap_per_epoch: u64,
        ctx: &mut TxContext
    ) {
        assert!(merchant::is_active(merchant_cap), E_MERCHANT_SUSPENDED);

        let treasury = TreasuryCap {
            id: object::new(ctx),
            merchant_id: merchant::id_of(merchant_cap),
            total_minted: 0,
            total_burned: 0,
            mint_cap_per_epoch,
            current_epoch_minted: 0,
            current_epoch: tx_context::epoch(ctx),
        };
        transfer::share_object(treasury);
    }

    // ------------------------------------------------------------------
    // TreasuryCap.reset_epoch_counter()
    // ------------------------------------------------------------------

    /// Reset bộ đếm mint của epoch hiện tại nếu hệ thống đã sang epoch mới.
    /// Được gọi tự động ở đầu mint_credit(), nhưng cũng có thể gọi thủ công.
    public entry fun reset_epoch_counter(treasury: &mut TreasuryCap, ctx: &TxContext) {
        let now_epoch = tx_context::epoch(ctx);
        if (now_epoch > treasury.current_epoch) {
            treasury.current_epoch = now_epoch;
            treasury.current_epoch_minted = 0;
        };
    }

    // ------------------------------------------------------------------
    // TreasuryCap.mint_credit() — luồng "Mint & Issue Credit Object"
    // ------------------------------------------------------------------

    /// Tính điểm thưởng dựa trên DynamicPolicyRule (EARN), kiểm tra hạn mức
    /// epoch của TreasuryCap, sau đó tạo một CreditObject mới và transfer
    /// cho người dùng. Phát MintEvent để Backend đồng bộ cache.
    public entry fun mint_credit(
        merchant_cap: &MerchantCap,
        treasury: &mut TreasuryCap,
        rule: &DynamicPolicyRule,
        user_addr: address,
        spend_amount: u64,
        now_ms: u64,
        ctx: &mut TxContext
    ) {
        assert!(merchant::is_active(merchant_cap), E_MERCHANT_SUSPENDED);
        assert!(treasury.merchant_id == merchant::id_of(merchant_cap), E_MERCHANT_MISMATCH);
        assert!(policy::merchant_id_of(rule) == merchant::id_of(merchant_cap), E_MERCHANT_MISMATCH);

        reset_epoch_counter(treasury, ctx);

        let points = policy::evaluate_earn(rule, spend_amount, now_ms);
        assert!(
            treasury.current_epoch_minted + points <= treasury.mint_cap_per_epoch,
            E_EPOCH_CAP_EXCEEDED
        );

        treasury.current_epoch_minted = treasury.current_epoch_minted + points;
        treasury.total_minted = treasury.total_minted + points;

        let credit = CreditObject {
            id: object::new(ctx),
            owner: user_addr,
            merchant_id: treasury.merchant_id,
            balance: points,
            tier: TIER_BRONZE,
            expiry_ms: option::none<u64>(),
            last_updated_ms: now_ms,
            locked: false,
        };
        let new_balance = credit.balance;

        event::emit(MintEvent {
            merchant_id: treasury.merchant_id,
            user_addr,
            points,
            new_balance,
        });

        transfer::transfer(credit, user_addr);
    }

    // ------------------------------------------------------------------
    // CreditObject.increase_balance() / decrease_balance() / lock / unlock
    // ------------------------------------------------------------------

    /// Cộng thêm điểm vào một CreditObject đã tồn tại (ví dụ merchant issue
    /// thêm điểm khuyến mãi vào object hiện có thay vì tạo object mới).
    public entry fun increase_balance(credit: &mut CreditObject, amount: u64, now_ms: u64) {
        assert!(!credit.locked, E_OBJECT_LOCKED);
        credit.balance = credit.balance + amount;
        credit.last_updated_ms = now_ms;
    }

    fun decrease_balance_internal(credit: &mut CreditObject, amount: u64, now_ms: u64) {
        assert!(credit.balance >= amount, E_INSUFFICIENT_BALANCE);
        credit.balance = credit.balance - amount;
        credit.last_updated_ms = now_ms;
    }

    /// API công khai để trừ số dư trực tiếp (dùng khi có nghiệp vụ cần trừ
    /// điểm ngoài luồng redeem chuẩn, ví dụ thu hồi điểm do gian lận).
    public entry fun decrease_balance(credit: &mut CreditObject, amount: u64, now_ms: u64) {
        assert!(!credit.locked, E_OBJECT_LOCKED);
        decrease_balance_internal(credit, amount, now_ms);
    }

    /// Khoá CreditObject trước khi xử lý redeem để chống double-spend khi
    /// có nhiều request redeem gửi đồng thời cho cùng một object.
    public entry fun lock_for_redeem(credit: &mut CreditObject) {
        assert!(!credit.locked, E_OBJECT_LOCKED);
        credit.locked = true;
    }

    /// Mở khoá CreditObject sau khi giao dịch redeem hoàn tất (thành công
    /// hoặc abort — luôn được gọi ở cuối cùng một Move call nên vẫn đảm bảo
    /// tính nguyên tử trong phạm vi một transaction).
    public entry fun unlock(credit: &mut CreditObject) {
        assert!(credit.locked, E_OBJECT_NOT_LOCKED);
        credit.locked = false;
    }

    // ------------------------------------------------------------------
    // redeem_and_burn() — luồng "Redeem & Burn Credit Object"
    // ------------------------------------------------------------------

    /// Lock → kiểm tra theo DynamicPolicyRule (REDEEM) → trừ số dư → cập
    /// nhật TreasuryCap.total_burned → phát RedeemEvent/BurnEvent → unlock.
    /// Toàn bộ nằm trong một Move call nên có tính nguyên tử tuyệt đối.
    public entry fun redeem_and_burn(
        credit: &mut CreditObject,
        treasury: &mut TreasuryCap,
        rule: &DynamicPolicyRule,
        redeem_amount: u64,
        now_ms: u64,
    ) {
        assert!(credit.merchant_id == treasury.merchant_id, E_CREDIT_MERCHANT_MISMATCH);
        assert!(policy::merchant_id_of(rule) == treasury.merchant_id, E_MERCHANT_MISMATCH);

        lock_for_redeem(credit);

        let valid = policy::evaluate_redeem(rule, redeem_amount, now_ms);
        assert!(valid, E_REDEEM_REJECTED_BY_POLICY);

        decrease_balance_internal(credit, redeem_amount, now_ms);
        treasury.total_burned = treasury.total_burned + redeem_amount;

        event::emit(RedeemEvent {
            merchant_id: credit.merchant_id,
            user_addr: credit.owner,
            amount: redeem_amount,
        });
        event::emit(BurnEvent {
            merchant_id: credit.merchant_id,
            user_addr: credit.owner,
            amount: redeem_amount,
            total_burned: treasury.total_burned,
        });

        unlock(credit);
    }

    // ------------------------------------------------------------------
    // View helpers (dùng cho test và cho Backend đọc trực tiếp qua devInspect)
    // ------------------------------------------------------------------
    public fun balance_of(credit: &CreditObject): u64 { credit.balance }
    public fun tier_of(credit: &CreditObject): u8 { credit.tier }
    public fun is_locked(credit: &CreditObject): bool { credit.locked }
    public fun total_minted_of(treasury: &TreasuryCap): u64 { treasury.total_minted }
    public fun total_burned_of(treasury: &TreasuryCap): u64 { treasury.total_burned }
}
