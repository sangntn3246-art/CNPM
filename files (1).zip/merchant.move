/// Module: octapoint::merchant
/// Quản lý AdminCap (capability gốc của hệ thống) và MerchantCap (capability
/// vận hành của từng merchant/tenant). Đây là module nền tảng, không phụ
/// thuộc vào bất kỳ module nào khác trong package để tránh circular
/// dependency với `policy` và `credit`.
module octapoint::merchant {
    use sui::object::{Self, UID, ID};
    use sui::tx_context::{Self, TxContext};
    use sui::transfer;
    use std::string::{Self, String};

    // ------------------------------------------------------------------
    // Error codes
    // ------------------------------------------------------------------
    const E_NOT_ADMIN: u64 = 0;
    const E_MERCHANT_SUSPENDED: u64 = 1;

    // ------------------------------------------------------------------
    // Trạng thái merchant
    // ------------------------------------------------------------------
    const STATUS_ACTIVE: u8 = 0;
    const STATUS_SUSPENDED: u8 = 1;
    const STATUS_TERMINATED: u8 = 2;

    // ------------------------------------------------------------------
    // Object Schema
    // ------------------------------------------------------------------

    /// Capability gốc của hệ thống. Được tạo duy nhất một lần trong init()
    /// và gửi cho ví deployer. Không có ability `store` nên KHÔNG thể
    /// transfer đi nơi khác sau khi đã cấp phát.
    public struct AdminCap has key {
        id: UID,
        admin_address: address,
        created_at_ms: u64,
    }

    /// Capability đại diện quyền vận hành của một merchant. Được AdminCap
    /// mint và transfer cho ví merchant trong bước onboarding.
    public struct MerchantCap has key, store {
        id: UID,
        tenant_id: ID,
        merchant_name: String,
        status: u8,
        issued_at_ms: u64,
    }

    // ------------------------------------------------------------------
    // Events
    // ------------------------------------------------------------------
    public struct MerchantCreatedEvent has copy, drop {
        merchant_id: ID,
        tenant_id: ID,
        merchant_name: String,
    }

    // ------------------------------------------------------------------
    // Init — chạy đúng một lần khi publish package
    // ------------------------------------------------------------------
    fun init(ctx: &mut TxContext) {
        let admin_cap = AdminCap {
            id: object::new(ctx),
            admin_address: tx_context::sender(ctx),
            created_at_ms: tx_context::epoch_timestamp_ms(ctx),
        };
        transfer::transfer(admin_cap, tx_context::sender(ctx));
    }

    // ------------------------------------------------------------------
    // AdminCap capabilities
    // ------------------------------------------------------------------

    /// Admin cấp MerchantCap mới cho một merchant khi onboard.
    public entry fun create_merchant_cap(
        _admin: &AdminCap,
        tenant_id: ID,
        merchant_name: vector<u8>,
        merchant_addr: address,
        ctx: &mut TxContext
    ) {
        let cap = MerchantCap {
            id: object::new(ctx),
            tenant_id,
            merchant_name: string::utf8(merchant_name),
            status: STATUS_ACTIVE,
            issued_at_ms: tx_context::epoch_timestamp_ms(ctx),
        };
        let merchant_id = object::id(&cap);

        sui::event::emit(MerchantCreatedEvent {
            merchant_id,
            tenant_id,
            merchant_name: cap.merchant_name,
        });

        transfer::transfer(cap, merchant_addr);
    }

    /// Admin tạm khoá một merchant (ví dụ vi phạm chính sách, gian lận).
    public entry fun pause_system(_admin: &AdminCap, cap: &mut MerchantCap) {
        cap.status = STATUS_SUSPENDED;
    }

    /// Admin mở khoá lại một merchant đã bị tạm khoá.
    public entry fun unpause_system(_admin: &AdminCap, cap: &mut MerchantCap) {
        cap.status = STATUS_ACTIVE;
    }

    /// Placeholder cho các cấu hình toàn cục trong tương lai (ví dụ: phí nền
    /// tảng, danh sách merchant bị chặn...). Hiện chỉ kiểm tra quyền Admin.
    public entry fun update_global_config(_admin: &AdminCap, _new_param: u64) {
        // Mở rộng khi hệ thống cần thêm tham số cấu hình toàn cục.
    }

    // ------------------------------------------------------------------
    // View / helper functions dùng bởi các module khác (policy, credit, audit)
    // ------------------------------------------------------------------
    public fun id_of(cap: &MerchantCap): ID { object::id(cap) }
    public fun status_of(cap: &MerchantCap): u8 { cap.status }
    public fun is_active(cap: &MerchantCap): bool { cap.status == STATUS_ACTIVE }

    #[test_only]
    public fun status_active(): u8 { STATUS_ACTIVE }
    #[test_only]
    public fun status_suspended(): u8 { STATUS_SUSPENDED }
}
