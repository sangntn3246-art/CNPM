/// Module: octapoint::policy
/// Lưu công thức tích điểm / đổi điểm hiện hành của một merchant. Có
/// versioning để tránh race-condition khi merchant cập nhật rule trong lúc
/// có giao dịch đang xử lý. Phụ thuộc vào `merchant` để kiểm tra quyền sở
/// hữu (MerchantCap), không phụ thuộc vào `credit`.
module octapoint::policy {
    use sui::object::{Self, UID, ID};
    use sui::tx_context::TxContext;
    use sui::transfer;
    use std::option::{Self, Option};

    use octapoint::merchant::{Self, MerchantCap};

    // ------------------------------------------------------------------
    // Error codes
    // ------------------------------------------------------------------
    const E_MERCHANT_SUSPENDED: u64 = 0;
    const E_MERCHANT_MISMATCH: u64 = 1;
    const E_WRONG_RULE_TYPE: u64 = 2;

    // ------------------------------------------------------------------
    // Loại rule
    // ------------------------------------------------------------------
    const RULE_EARN: u8 = 0;
    const RULE_REDEEM: u8 = 1;
    const RULE_TIER_UPGRADE: u8 = 2;

    /// Mẫu số basis point dùng để biểu diễn hệ số nhân dạng số nguyên
    /// (10 000 = hệ số x1.0), tránh phải dùng số thực trong Move.
    const BPS_DENOMINATOR: u64 = 10000;

    // ------------------------------------------------------------------
    // Object Schema
    // ------------------------------------------------------------------
    public struct DynamicPolicyRule has key, store {
        id: UID,
        merchant_id: ID,
        rule_type: u8,
        multiplier_bps: u64,
        min_spend: u64,
        max_point_per_tx: u64,
        valid_from_ms: u64,
        valid_to_ms: Option<u64>,
        version: u64,
    }

    // ------------------------------------------------------------------
    // MerchantCap.create_policy_rule()
    // ------------------------------------------------------------------

    /// Merchant tạo mới một rule (earn/redeem/tier-upgrade) và publish thành
    /// shared object để mọi giao dịch mint/redeem có thể đọc/tham chiếu.
    public entry fun create_policy_rule(
        merchant_cap: &MerchantCap,
        rule_type: u8,
        multiplier_bps: u64,
        min_spend: u64,
        max_point_per_tx: u64,
        valid_from_ms: u64,
        has_expiry: bool,
        valid_to_ms: u64,
        ctx: &mut TxContext
    ) {
        assert!(merchant::is_active(merchant_cap), E_MERCHANT_SUSPENDED);

        let expiry: Option<u64> = if (has_expiry) {
            option::some(valid_to_ms)
        } else {
            option::none<u64>()
        };

        let rule = DynamicPolicyRule {
            id: object::new(ctx),
            merchant_id: merchant::id_of(merchant_cap),
            rule_type,
            multiplier_bps,
            min_spend,
            max_point_per_tx,
            valid_from_ms,
            valid_to_ms: expiry,
            version: 1,
        };
        transfer::share_object(rule);
    }

    /// Tăng version của rule mỗi lần merchant cập nhật tham số. Backend
    /// dùng version này để phát hiện và bỏ qua các quyết định tính điểm dựa
    /// trên rule đã cũ (đọc trước, ghi sau race-condition).
    public entry fun bump_version(merchant_cap: &MerchantCap, rule: &mut DynamicPolicyRule) {
        assert!(rule.merchant_id == merchant::id_of(merchant_cap), E_MERCHANT_MISMATCH);
        rule.version = rule.version + 1;
    }

    /// Cho phép merchant chỉnh các tham số vận hành mà không cần tạo rule mới.
    public entry fun update_rule_params(
        merchant_cap: &MerchantCap,
        rule: &mut DynamicPolicyRule,
        multiplier_bps: u64,
        min_spend: u64,
        max_point_per_tx: u64,
    ) {
        assert!(rule.merchant_id == merchant::id_of(merchant_cap), E_MERCHANT_MISMATCH);
        rule.multiplier_bps = multiplier_bps;
        rule.min_spend = min_spend;
        rule.max_point_per_tx = max_point_per_tx;
        rule.version = rule.version + 1;
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------
    fun is_time_valid(rule: &DynamicPolicyRule, now_ms: u64): bool {
        if (now_ms < rule.valid_from_ms) {
            return false
        };
        if (option::is_some(&rule.valid_to_ms)) {
            let expiry = *option::borrow(&rule.valid_to_ms);
            if (now_ms > expiry) {
                return false
            };
        };
        true
    }

    // ------------------------------------------------------------------
    // DynamicPolicyRule.evaluate_earn() / evaluate_redeem()
    // Được gọi từ module `credit` (đọc-only, không entry).
    // ------------------------------------------------------------------

    /// Tính số điểm được tích dựa trên số tiền chi tiêu, áp trần
    /// max_point_per_tx. Trả về 0 nếu rule không còn hiệu lực hoặc chi tiêu
    /// chưa đạt ngưỡng min_spend.
    public fun evaluate_earn(rule: &DynamicPolicyRule, spend_amount: u64, now_ms: u64): u64 {
        assert!(rule.rule_type == RULE_EARN, E_WRONG_RULE_TYPE);
        if (!is_time_valid(rule, now_ms)) {
            return 0
        };
        if (spend_amount < rule.min_spend) {
            return 0
        };
        let raw_points = (spend_amount * rule.multiplier_bps) / BPS_DENOMINATOR;
        if (raw_points > rule.max_point_per_tx) {
            rule.max_point_per_tx
        } else {
            raw_points
        }
    }

    /// Kiểm tra một yêu cầu đổi điểm có hợp lệ theo rule REDEEM hiện hành
    /// hay không (còn hiệu lực thời gian + không vượt trần mỗi giao dịch).
    public fun evaluate_redeem(rule: &DynamicPolicyRule, redeem_amount: u64, now_ms: u64): bool {
        assert!(rule.rule_type == RULE_REDEEM, E_WRONG_RULE_TYPE);
        if (!is_time_valid(rule, now_ms)) {
            return false
        };
        if (redeem_amount > rule.max_point_per_tx) {
            return false
        };
        true
    }

    // ------------------------------------------------------------------
    // View helpers
    // ------------------------------------------------------------------
    public fun merchant_id_of(rule: &DynamicPolicyRule): ID { rule.merchant_id }
    public fun version_of(rule: &DynamicPolicyRule): u64 { rule.version }
}
