/// Module: octapoint::audit
/// Lưu tham chiếu (không lưu nội dung) tới bằng chứng kiểm toán đã mã hoá
/// được lưu trên Walrus, nhằm tối ưu chi phí lưu trữ on-chain trong khi vẫn
/// đảm bảo tính bất biến và có thể xác minh (digest) bất kỳ lúc nào.
module octapoint::audit {
    use sui::object::{Self, UID, ID};
    use sui::tx_context::{Self, TxContext};
    use sui::transfer;

    use octapoint::merchant::{Self, MerchantCap};

    // ------------------------------------------------------------------
    // Error codes
    // ------------------------------------------------------------------
    const E_MERCHANT_SUSPENDED: u64 = 0;
    const E_INVALID_BLOB_ID: u64 = 1;
    const E_INVALID_DIGEST: u64 = 2;

    // ------------------------------------------------------------------
    // Object Schema
    // ------------------------------------------------------------------
    public struct AuditLogRef has key, store {
        id: UID,
        merchant_id: ID,
        blob_id: vector<u8>,
        digest: vector<u8>,
        recorded_epoch: u64,
    }

    // ------------------------------------------------------------------
    // Events
    // ------------------------------------------------------------------
    public struct AuditRecordedEvent has copy, drop {
        merchant_id: ID,
        blob_id: vector<u8>,
        recorded_epoch: u64,
    }

    // ------------------------------------------------------------------
    // MerchantCap.request_walrus_offload()
    // Backend gọi hàm này SAU KHI đã publish blob mã hoá lên Walrus và xác
    // minh Proof-of-Availability (PoA) — xem Sequence Diagram mục 4.4.4.
    // ------------------------------------------------------------------
    public entry fun record_blob_reference(
        merchant_cap: &MerchantCap,
        blob_id: vector<u8>,
        digest: vector<u8>,
        ctx: &mut TxContext
    ) {
        assert!(merchant::is_active(merchant_cap), E_MERCHANT_SUSPENDED);
        assert!(std::vector::length(&blob_id) > 0, E_INVALID_BLOB_ID);
        assert!(std::vector::length(&digest) == 32, E_INVALID_DIGEST); // SHA-256 = 32 bytes

        let merchant_id = merchant::id_of(merchant_cap);
        let recorded_epoch = tx_context::epoch(ctx);

        let log_ref = AuditLogRef {
            id: object::new(ctx),
            merchant_id,
            blob_id,
            digest,
            recorded_epoch,
        };

        sui::event::emit(AuditRecordedEvent {
            merchant_id,
            blob_id: log_ref.blob_id,
            recorded_epoch,
        });

        // Lưu tại ví của Backend Service Account (owned object) để dễ dàng
        // truy vấn lịch sử audit theo từng merchant khi cần đối soát.
        transfer::transfer(log_ref, tx_context::sender(ctx));
    }

    // ------------------------------------------------------------------
    // View helpers
    // ------------------------------------------------------------------
    public fun blob_id_of(log_ref: &AuditLogRef): vector<u8> { log_ref.blob_id }
    public fun digest_of(log_ref: &AuditLogRef): vector<u8> { log_ref.digest }
    public fun merchant_id_of(log_ref: &AuditLogRef): ID { log_ref.merchant_id }
}
